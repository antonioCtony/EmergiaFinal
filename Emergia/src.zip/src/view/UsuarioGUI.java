package view;

import model.EmergiaCalculator;
import model.EmergiaInput;
import model.Usuario;
import utilatery.Criptografia;
import utilatery.Validador;

import javax.swing.*;
import java.awt.*;
import java.io.*;

public class UsuarioGUI {

    private Usuario usuarioLogado;
    private JPanel painelEmergia;
    private JTabbedPane abas;

    private JComboBox<String> comboTipoResfriamento;
    private JTextField campoConsumoResfriamento;
    private JTextField campoEficienciaCOP;
    private JTextField campoFluxoAr;
    private JTextField campoTemperaturaEntrada;
    private JTextField campoTemperaturaSaida;
    private JTextField campoVazaoAgua;
    private JTextField campoHorasOperacao;
    private JPanel painelCamposResfriamento;

    public void exibirInterface() {
        JFrame frame = new JFrame("Sistema de Sustentabilidade");
        frame.setSize(700, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);

        abas = new JTabbedPane();
        abas.addTab("Cadastro", criarPainelCadastro());
        abas.addTab("Login", criarPainelLogin());

        painelEmergia = criarPainelEmergia();
        abas.addTab("Emergia", painelEmergia);
        abas.setEnabledAt(2, false);

        frame.add(abas);
        frame.setVisible(true);
    }

    private JPanel criarPainelCadastro() {
        JPanel painel = new JPanel(new GridLayout(5, 2, 10, 10));
        JTextField nomeField = new JTextField();
        JTextField emailField = new JTextField();
        JPasswordField senhaField = new JPasswordField();
        JLabel mensagem = new JLabel();
        JButton cadastrarButton = new JButton("Cadastrar");

        painel.add(new JLabel("Nome:"));
        painel.add(nomeField);
        painel.add(new JLabel("Email:"));
        painel.add(emailField);
        painel.add(new JLabel("Senha:"));
        painel.add(senhaField);
        painel.add(new JLabel());
        painel.add(cadastrarButton);
        painel.add(mensagem);

        cadastrarButton.addActionListener(e -> {
            String nome = nomeField.getText().trim();
            String email = emailField.getText().trim();
            String senha = new String(senhaField.getPassword());

            if (nome.isEmpty() || email.isEmpty() || senha.isEmpty()) {
                mensagem.setText("❌ Preencha todos os campos.");
                return;
            }

            if (!Validador.validarEmail(email)) {
                mensagem.setText("❌ Email inválido.");
                return;
            }

            if (!Validador.validarSenha(senha)) {
                mensagem.setText("❌ Senha fraca.");
                return;
            }

            String hash = Criptografia.gerarHash(senha);

            try (FileWriter fw = new FileWriter("usuarios.txt", true)) {
                fw.write(nome + "," + email + "," + hash + "\n");
                mensagem.setText("✅ Cadastro realizado.");
            } catch (IOException ex) {
                mensagem.setText("❌ Erro: " + ex.getMessage());
            }
        });

        return painel;
    }

    private JPanel criarPainelLogin() {
        JPanel painel = new JPanel(new GridLayout(4, 2, 10, 10));
        JTextField emailField = new JTextField();
        JPasswordField senhaField = new JPasswordField();
        JButton loginButton = new JButton("Login");
        JLabel mensagem = new JLabel();

        painel.add(new JLabel("Email:"));
        painel.add(emailField);
        painel.add(new JLabel("Senha:"));
        painel.add(senhaField);
        painel.add(new JLabel());
        painel.add(loginButton);
        painel.add(mensagem);

        loginButton.addActionListener(e -> {
            String email = emailField.getText().trim();
            String senha = new String(senhaField.getPassword());

            try (BufferedReader reader = new BufferedReader(new FileReader("usuarios.txt"))) {
                String linha;
                while ((linha = reader.readLine()) != null) {
                    String[] partes = linha.split(",");
                    if (partes.length == 3 && partes[1].equals(email)) {
                        if (Criptografia.verificarSenha(senha, partes[2])) {
                            usuarioLogado = new Usuario(partes[0], partes[1], partes[2]);
                            mensagem.setText("✅ Bem-vindo, " + partes[0] + "!");
                            abas.setEnabledAt(2, true);
                            abas.setSelectedIndex(2);
                        } else {
                            mensagem.setText("❌ Senha incorreta.");
                        }
                        return;
                    }
                }
                mensagem.setText("❌ Usuário não encontrado.");
            } catch (IOException ex) {
                mensagem.setText("❌ Erro: " + ex.getMessage());
            }
        });

        return painel;
    }

    private JPanel criarPainelEmergia() {
        JPanel painel = new JPanel();
        painel.setLayout(new BoxLayout(painel, BoxLayout.Y_AXIS));

        // Tipo de resfriamento
        JPanel painelTipo = new JPanel(new GridLayout(0, 1, 1, 1));
        JLabel labelTipo = new JLabel("Tipo de Resfriamento:");
        comboTipoResfriamento = new JComboBox<>(new String[]{"Ar", "Líquido", "Evaporativo"});
        comboTipoResfriamento.setPreferredSize(new Dimension(60, 25));
        painelTipo.add(labelTipo);
        painelTipo.add(comboTipoResfriamento);
        painel.add(painelTipo);

        // Painel campos dinâmicos
        painelCamposResfriamento = new JPanel(new GridLayout(0, 2, 5, 5));
        painelCamposResfriamento.setBorder(BorderFactory.createTitledBorder("Dados do Resfriamento"));
        painel.add(painelCamposResfriamento);

        // Campos padrão
        campoConsumoResfriamento = new JTextField();
        campoEficienciaCOP = new JTextField();
        campoFluxoAr = new JTextField();
        campoTemperaturaEntrada = new JTextField();
        campoTemperaturaSaida = new JTextField();
        campoVazaoAgua = new JTextField();
        campoHorasOperacao = new JTextField();

        // Atualiza os campos dinamicamente
        comboTipoResfriamento.addActionListener(e -> atualizarCamposResfriamento());

        atualizarCamposResfriamento(); // chamada inicial

        // Botão calcular
        JButton botao = new JButton("Calcular");
        botao.addActionListener(e -> realizarCalculo());
        painel.add(botao);

        return painel;
    }

    private void atualizarCamposResfriamento() {
        painelCamposResfriamento.removeAll();

        painelCamposResfriamento.add(new JLabel("Consumo (kWh):"));
        painelCamposResfriamento.add(campoConsumoResfriamento);

        painelCamposResfriamento.add(new JLabel("Eficiência (COP):"));
        painelCamposResfriamento.add(campoEficienciaCOP);

        painelCamposResfriamento.add(new JLabel("Horas por dia:"));
        painelCamposResfriamento.add(campoHorasOperacao);

        String tipo = (String) comboTipoResfriamento.getSelectedItem();

        if ("Ar".equals(tipo) || "Evaporativo".equals(tipo)) {
            painelCamposResfriamento.add(new JLabel("Fluxo de Ar (m³/h):"));
            painelCamposResfriamento.add(campoFluxoAr);
        } else if ("Líquido".equals(tipo)) {
            painelCamposResfriamento.add(new JLabel("Temperatura Entrada (°C):"));
            painelCamposResfriamento.add(campoTemperaturaEntrada);

            painelCamposResfriamento.add(new JLabel("Temperatura Saída (°C):"));
            painelCamposResfriamento.add(campoTemperaturaSaida);

            painelCamposResfriamento.add(new JLabel("Vazão da Água (L/min):"));
            painelCamposResfriamento.add(campoVazaoAgua);
        }

        painelCamposResfriamento.revalidate();
        painelCamposResfriamento.repaint();
    }

    private void realizarCalculo() {
        try {
            EmergiaInput input = new EmergiaInput();
            input.setTipoResfriamento((String) comboTipoResfriamento.getSelectedItem());
            input.setConsumoResfriamento(Double.parseDouble(campoConsumoResfriamento.getText()));
            input.setEficienciaCOP(Double.parseDouble(campoEficienciaCOP.getText()));
            input.setHorasOperacao(Double.parseDouble(campoHorasOperacao.getText()));

            String tipo = input.getTipoResfriamento();
            if ("Ar".equals(tipo) || "Evaporativo".equals(tipo)) {
                input.setFluxoAr(Double.parseDouble(campoFluxoAr.getText()));
            } else if ("Líquido".equals(tipo)) {
                input.setTemperaturaEntrada(Double.parseDouble(campoTemperaturaEntrada.getText()));
                input.setTemperaturaSaida(Double.parseDouble(campoTemperaturaSaida.getText()));
                input.setVazaoAgua(Double.parseDouble(campoVazaoAgua.getText()));
            }

            EmergiaCalculator calc = new EmergiaCalculator();
            String relatorio = calc.gerarRelatorio(input);

            JOptionPane.showMessageDialog(null, relatorio, "Resultado", JOptionPane.INFORMATION_MESSAGE);

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Preencha todos os campos com valores válidos.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new UsuarioGUI().exibirInterface());
    }
}
