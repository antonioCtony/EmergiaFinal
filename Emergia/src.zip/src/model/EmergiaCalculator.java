package model;

public class EmergiaCalculator {

    public String gerarRelatorio(EmergiaInput input) {
        StringBuilder relatorio = new StringBuilder();
        relatorio.append("🔍 Relatório de Sustentabilidade do Sistema\n");
        relatorio.append("--------------------------------------------\n");
        relatorio.append("Tipo de Resfriamento: ").append(input.getTipoResfriamento()).append("\n");
        relatorio.append("Consumo (kWh): ").append(input.getConsumoResfriamento()).append("\n");
        relatorio.append("Eficiência (COP): ").append(input.getEficienciaCOP()).append("\n");
        relatorio.append("Horas por dia: ").append(input.getHorasOperacao()).append("\n");

        double energiaTotal = input.getConsumoResfriamento() * input.getHorasOperacao();

        switch (input.getTipoResfriamento()) {
            case "Ar":
            case "Evaporativo":
                relatorio.append("Fluxo de Ar (m³/h): ").append(input.getFluxoAr()).append("\n");
                break;
            case "Líquido":
                relatorio.append("Temperatura de Entrada: ").append(input.getTemperaturaEntrada()).append(" °C\n");
                relatorio.append("Temperatura de Saída: ").append(input.getTemperaturaSaida()).append(" °C\n");
                relatorio.append("Vazão da Água: ").append(input.getVazaoAgua()).append(" L/min\n");
                break;
        }

        relatorio.append("--------------------------------------------\n");
        relatorio.append("🔢 Energia Total Estimada por Dia: ").append(String.format("%.2f", energiaTotal)).append(" kWh\n");

        boolean sustentavel = avaliarSustentabilidade(energiaTotal, input);
        relatorio.append("💡 Status do Sistema: ").append(sustentavel ? "✅ Sustentável" : "❌ Não Sustentável").append("\n");

        return relatorio.toString();
    }

    private boolean avaliarSustentabilidade(double energiaTotal, EmergiaInput input) {
        // Regras básicas: valores fictícios para exemplo
        if (energiaTotal > 1000) return false;
        if (input.getEficienciaCOP() < 2.5) return false;

        if ("Líquido".equals(input.getTipoResfriamento())) {
            double deltaTemp = input.getTemperaturaSaida() - input.getTemperaturaEntrada();
            if (deltaTemp < 3 || input.getVazaoAgua() > 200) return false;
        }

        return true;
    }
}
