package model;

public class RelatorioService {

    public String gerarResumo(EmergiaInput input) {
        EmergiaCalculator calculator = new EmergiaCalculator();
        return calculator.gerarRelatorio(input);
    }
}
